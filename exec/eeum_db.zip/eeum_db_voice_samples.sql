-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: eeum-rds.cvmcs64e0y2c.ap-northeast-2.rds.amazonaws.com    Database: eeum_db
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `voice_samples`
--

DROP TABLE IF EXISTS `voice_samples`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `voice_samples` (
  `duration_sec` double NOT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `script_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  `voice_task_id` int DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `sample_path` varchar(255) NOT NULL,
  `test_audio_path` varchar(255) DEFAULT NULL,
  `transcript` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK2yq8qroqjfg9n143a7r9rq5st` (`voice_task_id`),
  KEY `FK744cgl68daag57fsfvs12q36f` (`user_id`),
  KEY `FK80wap2nwfesijr1w13fr84b0p` (`script_id`),
  CONSTRAINT `FK744cgl68daag57fsfvs12q36f` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `FK80wap2nwfesijr1w13fr84b0p` FOREIGN KEY (`script_id`) REFERENCES `voice_scripts` (`id`),
  CONSTRAINT `FKr7fkxscuqojltt4a2n55u5vjy` FOREIGN KEY (`voice_task_id`) REFERENCES `voice_tasks` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voice_samples`
--

LOCK TABLES `voice_samples` WRITE;
/*!40000 ALTER TABLE `voice_samples` DISABLE KEYS */;
INSERT INTO `voice_samples` VALUES (3.4,5,4,2,6,'2026-02-05 13:10:43.334834','2026-02-05 13:10:59.036668','Script 4','samples/2/cc3d5fd8-a02c-4d88-bed2-03aabd7bdb27.webm','generated/2/103e5f08-bc12-4adb-859a-a2d3d3f4253d.wav',NULL),(5.3,6,5,2,7,'2026-02-05 13:10:56.556518','2026-02-05 13:11:09.453428','Script 5','samples/2/2c89c733-27a7-4f78-a6c2-03d95acd763c.webm','generated/2/a42742cb-5ff3-4cef-9713-5d1d6957773a.wav',NULL),(5.1,10,1,2,12,'2026-02-05 14:35:21.819189','2026-02-05 14:35:35.891015','Script 1','samples/2/6f8c5d3a-8b0f-4c9a-bf85-7ed61de2dd6a.webm','generated/2/705b447a-c2d0-458c-a168-6f2a1e5d57f4.wav',NULL),(4.3,12,1,3,15,'2026-02-05 16:16:16.268898','2026-02-05 16:16:23.431548','Script 1','samples/3/3d6f2fe0-91ea-4b2e-83f0-25d1b3579ab3.webm','generated/3/2502b891-0ab5-4e7a-bbe8-3bbd8c0807e1.wav',NULL),(7.5,13,1,3,16,'2026-02-05 16:22:10.282481','2026-02-05 16:22:24.319478','Script 1','samples/3/09f6137f-81aa-4c0f-b91b-1d1c21fb28a4.webm','generated/3/926e4f24-06f7-4e0d-9d1e-b2387f69b207.wav',NULL),(4.6,18,1,6,25,'2026-02-05 17:30:05.530280','2026-02-05 17:30:23.836206','Script 1','samples/6/9fc304d4-dfe5-4cdc-a5c0-964ba4288b6e.webm','generated/6/df4e3c9e-e0a9-40d1-846b-bd71fee8b010.wav',NULL),(4.6,19,1,6,26,'2026-02-05 17:30:05.890097','2026-02-05 17:31:06.413742','Script 1','samples/6/260a687b-0be4-4205-a387-d9255b28c127.webm','generated/6/3152083e-9457-49db-8155-86b142d0d61b.wav',NULL),(4.2,20,2,6,27,'2026-02-05 17:30:16.571505','2026-02-05 17:30:23.926559','Script 2','samples/6/0a8d1d15-28e6-419e-9f71-8f96a62f3027.webm','generated/6/261bb6c8-6999-4cac-9a32-f0639435d9da.wav',NULL),(4.3,21,3,6,28,'2026-02-05 17:30:32.248545','2026-02-05 17:30:45.476128','Script 3','samples/6/555aafc0-7f6e-4315-bea4-c3113af72ca1.webm','generated/6/6e27e69f-cb3e-4e05-974b-e3764887aeed.wav',NULL),(3.1,22,4,6,29,'2026-02-05 17:30:44.850562','2026-02-05 17:30:55.756134','Script 4','samples/6/86558eac-a564-468a-8ea0-1655d5d5b4f7.webm','generated/6/8d20938e-3e93-486e-a44e-f2fc449aa73a.wav',NULL),(3.8,23,5,6,30,'2026-02-05 17:30:58.270488','2026-02-05 17:31:17.509261','Script 5','samples/6/c17bf61b-28f6-4220-ae9e-18852477d35a.webm','generated/6/74c6d440-973a-431a-915a-9b9c602b36fe.wav',NULL),(4.1,24,4,3,35,'2026-02-05 17:39:15.035646','2026-02-05 17:39:28.374640','Script 4','samples/3/89b5d6f3-5900-4744-b2db-d28665c8860b.webm','generated/3/f189d0c1-0610-4eb8-8b54-c3df742007a0.wav',NULL),(5.4,25,NULL,3,36,'2026-02-05 17:41:32.455504','2026-02-06 15:03:47.572928','아그....없네','samples/3/4c39556f-4114-4004-aaa5-8c962ca5ffba.webm','generated/3/a0e026ab-76d5-4707-9838-cb810de97aa7.wav','아 마이크 테스트 하나 둘 아 아 마이크 테스트 하나 둘'),(5,28,1,3,44,'2026-02-05 18:29:09.886080','2026-02-05 18:29:25.764622','Script 1','samples/3/8cd2955c-9735-4582-bc33-f801aebb7592.webm','generated/3/11f71a3d-ee03-4d70-9a0d-9f5d2b9cc82f.wav',NULL),(4.7,29,5,3,52,'2026-02-06 14:46:32.257848','2026-02-06 14:46:49.487608','Script 5','samples/3/ee5e9b52-f9aa-450e-baaf-09eb05379363.webm','generated/3/42f16428-90b3-4e6a-b553-e0576b4a796a.wav',NULL),(3.9,30,1,9,55,'2026-02-06 14:50:43.852601','2026-02-06 14:51:35.972557','Script 1','samples/9/5ad3bd1d-6282-46c8-912f-6c55cf4d9456.webm','generated/9/926bae90-b42f-49ce-b856-2bb63abcb339.wav',NULL),(4.2,33,4,4,74,'2026-02-06 19:30:16.313921','2026-02-06 19:30:28.107288','Script 4','samples/4/12b8f1c7-f824-4727-9513-7e87d8868552.webm','generated/4/817818ea-46a3-4f70-bf5d-992297524935.wav',NULL),(5.1,36,2,7,86,'2026-02-07 17:41:25.841785','2026-02-07 17:41:42.620864','Script 2','samples/7/0fc3aa4a-7e99-4357-8467-04a147e488db.webm','generated/7/c5e004e2-c046-443b-b266-10ec012811d2.wav',NULL),(4.8,37,2,9,95,'2026-02-07 19:16:49.670456','2026-02-07 19:17:01.400404','Script 2','samples/9/b44ae25c-1112-4dfb-affa-7d99a165485c.webm','generated/9/ce5a2fb0-4526-471c-ad66-4e64da4f525f.wav',NULL),(8.7,38,NULL,9,96,'2026-02-07 19:17:07.324882','2026-02-07 19:17:21.982363','Free Talk','samples/9/d5c8826b-48f8-4f8f-ba6a-24e2d5ea3adc.webm','generated/9/7508066e-69cb-495e-b2f7-6a3e5cda9a15.wav','요즘에 대체 무슨 일이 일어나는지 잘 모르겠군요 알고 싶습니다'),(4,39,2,2,104,'2026-02-07 19:43:13.128292','2026-02-07 19:43:28.329539','Script 2','samples/2/39094787-e7ce-4f3a-9243-ca7147580e2a.webm','generated/2/1be68cb2-d8a0-4f85-b536-9394e50aa25a.wav',NULL),(5.5,40,NULL,2,109,'2026-02-07 19:48:38.680511','2026-02-07 19:48:51.256585','Free Talk','samples/2/46c28f8f-f541-4a0a-8b3c-8e8b0ac47fe2.webm','generated/2/d9de1cd6-7fc6-4525-b430-dd11effb04ef.wav','내일부터 다시 추워진다고 합니다. 건강하시게 지내세요.'),(5.7,41,3,9,156,'2026-02-08 23:14:32.066777','2026-02-08 23:14:51.894076','Script 3','samples/9/212e5fbf-2a05-4ae7-8cfd-d84925291f94.webm','generated/9/f9770899-98e6-47ff-b379-19422f9cea0a.wav',NULL),(7.6,42,NULL,9,157,'2026-02-08 23:15:07.936578','2026-02-08 23:15:22.478564','Free Talk','samples/9/fac098ac-5780-4c57-862c-54a82dbae3ae.webm','generated/9/b5cf5324-f373-4085-8e2d-6479cc408f3f.wav','고맙습니다.');
/*!40000 ALTER TABLE `voice_samples` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-09  9:35:17
