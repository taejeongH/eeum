-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: eeum-rds.cvmcs64e0y2c.ap-northeast-2.rds.amazonaws.com    Database: eeum_db
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `birth_date` date DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `is_email_verified` bit(1) NOT NULL,
  `representative_sample_id` int DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `fcm_token` varchar(1000) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `blood_type` varchar(255) DEFAULT NULL,
  `chronic_diseases` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `gender` enum('M','F') DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK719ukpmw8o67gax6wwqsn84bs` (`representative_sample_id`),
  CONSTRAINT `FKqnxrg0saw6ewroty6cwke7aq5` FOREIGN KEY (`representative_sample_id`) REFERENCES `voice_samples` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('1998-09-14',1,_binary '\0',NULL,'2026-02-05 12:10:27.347344',NULL,'2026-02-09 08:07:18.000953','010-7613-2359','큰아들','dFMGrlGuTgGPjgq2P5BUod:APA91bF6JVShvMBnFKRoj301vtFUaC9D5rFFc-8LfbOyRvyXJeGQFg7ALsQRruvHkvE6DbWUSxq5vvu7CQ5OVEShbJdzoJvJIAUTDJE99Zii1oFXhOAXzY0','서울 강서구 방화동 246-34','A+',NULL,'kakao_4711385372@social.eeum',NULL,NULL,'profile/7d937fca-e9f4-4fa8-bc30-0554b89e8f66-ChatGPT Image 2026년 2월 8일 오후 09_21_26.png','M'),('2018-03-08',2,_binary '\0',39,'2026-02-05 12:14:07.590573',NULL,'2026-02-09 08:09:24.813250','010-1234-5678','손녀','eCfDAkyFSt6diox9dhTbz5:APA91bHLTXin1ZwxS55eHPIOtXmXuEeXsdJWHmD_HuRBNfftBPs9MAFMBJTLNbETt-cU1ZD3JXpYkXlimrUo2d05iVFOT0rLe_FaKscZwMvjKYjmhujJISk','서울 용산구 남산공원길 105',NULL,NULL,'kakao_4711854930@social.eeum',NULL,NULL,'profile/a4b54619-3d0b-42e1-b730-e039841f8c2b-1000009305.png','F'),('1925-08-11',3,_binary '\0',28,'2026-02-05 12:15:56.608715',NULL,'2026-02-09 09:02:30.195273','010-6608-7622','김옥순','clPeko6bT0-ejViAnw0aX-:APA91bHMe6jO0z99Y9a84pubdlGB4EBN_zdlSO6A7r12Dru-JVugcfwCYXcmlxM8z7wEWlIPWJLUknBckMgngk-3m3hGLKr84H40pj_qTQjJ2TvJehSAfk0','전남 신안군 도초면 고란길 1 302','A+',NULL,'kakao_4709894052@social.eeum',NULL,NULL,'profile/09b9cf06-33a1-45cb-bffb-2178b4111e48-images.jpeg','F'),('1972-09-01',4,_binary '',33,'2026-02-05 12:24:56.185827',NULL,'2026-02-06 21:39:23.308723','010-5654-6778','첫째 며느리','fhh9EFo9RA-FDDlkVv33vp:APA91bG_0SKGyEw1HpGCb4LRLWhumFsuc7K-kTOgNGpVC7lKd3P0El2StFLjd6fc69_WL4VKdFiZhnWkf_e_HN72Ja86q8K0FsrRRDPnRLiswan4kZezWfg','서울 강남구 강남대로 302 302','A+',NULL,'tdj5654@naver.com',NULL,'$2a$10$mtAmzS.vrUujD/d3FQpm7.6jZT7UR24Drf1uhM9HKI2lKYzVxFt/G','profile/1f7396ca-bdd3-4f26-9c35-e1fe0ad259e4-다운로드파일_20260116_193956.jpg','F'),('1972-05-21',6,_binary '\0',22,'2026-02-05 13:07:43.479450',NULL,'2026-02-09 07:55:55.118625','010-6605-0732','첫째 며느리','euqlSmN0RAO1S2gOddt1wZ:APA91bGF-zaPQR0__EwQL_9otr0FZ4b5GhKYd-LjDTe_DBZVjdZ0Sn9KNT5pixeNGk-0gWzkn-d32QtA1Nl4tH_e1JARFTd9-vLMmpoNgOseCvcvME73ocw','서울 강남구 테헤란로 212 멀티캠퍼스',NULL,NULL,'kakao_4734823840@social.eeum',NULL,NULL,'profile/31d39581-d650-42af-8798-62f9e7d97091-file_000000005c64720899d6c9702df7aa09.png','F'),('1997-02-21',7,_binary '\0',36,'2026-02-05 15:24:04.310247',NULL,'2026-02-09 08:04:29.025869','010-9361-7110','막내 딸','eOvNKobgTiSiGT1gf2BZKE:APA91bFtebyBWM9iGkwUHGaPDR0QbRUme8pMwm84yrZjFMpI15pC1QPLPwIhqwPK0WyPijoJ31GYWZzwERWWxB-bS-9MtxTRqwniasvp5JLrC8be6sH2DG8','경기 하남시 감일백제로 20 301동 1002호',NULL,NULL,'kakao_4718817114@social.eeum',NULL,NULL,'profile/f15aa3ef-64ba-4a4f-934b-33ebb348d11f-kakao_profile.jpg','M'),('1998-02-14',8,_binary '',NULL,'2026-02-05 21:52:18.208892',NULL,'2026-02-06 21:02:12.994854','010-7613-2359','허태정','egKFRl19Q-6IpfGrbMqGn8:APA91bFfc039ohLZFQiNbpnsqf3PoLUEspbxStYlDIUo2RjBs5wroDV0Gc6uYRVZFVWOa5e6xectKFpq4Cysh3tDGyrDhLIefcIMeW3IlmxlYBfaAF6zRb0','경기 김포시 대곶면 대곶로119번길 81',NULL,NULL,'taejeongH98@gmail.com',NULL,'$2a$10$gXkhoWmrp5Lby.OtIA996ewm29sxxJZVbBCqPGbGNmXL0IIER/3Jy','profile/taejeon_default_image.png','M'),('1982-06-22',9,_binary '\0',38,'2026-02-06 13:25:01.079717',NULL,'2026-02-09 08:32:37.790665','010-5654-6778','최서방','fmbKwzj5QiC5LDLLa_3XHy:APA91bEgYtnx3llXfxjju4vKwkh7Ne_jmbptiM6WPfPHRWLASG-UL7duhWrK2Apt6l-AVB4hHEALnLWUhHuPxExIDaqvxYMXttvuLj7Bdq3JO87mUk7TCko','서울 강남구 역삼로1길 18 312호',NULL,NULL,'kakao_4716742459@social.eeum',NULL,NULL,'profile/6d2933df-e72f-4c0a-ad18-2757d8a2b50c-1770423426304.jpg','M'),('2000-06-17',10,_binary '',NULL,'2026-02-06 14:32:00.075524',NULL,'2026-02-06 14:33:23.449634','010-9407-1084','윤진원',NULL,'경북 구미시 3공단3로 302 .',NULL,NULL,'dnj1510@gmail.com',NULL,'$2a$10$t4f.Sbgv9DnAYdFcYQNXRelDJawsZtc0oyD4ULqk3DIoeBKIyR0JG','profile/taejeon_default_image.png','M'),('1998-12-29',11,_binary '',NULL,'2026-02-06 14:35:46.999613',NULL,'2026-02-06 14:36:30.465809','010-3026-0663','이건',NULL,'경북 구미시 3공단3로 302 한마음플라자',NULL,NULL,'sedrick743@gmail.com',NULL,'$2a$10$pNv6mBqgGAhWcAF/z4KI2eQSvRZGNRH0C6SlTneQXMk6p8ZHgSIb.','profile/taejeon_default_image.png','M'),('2000-11-12',12,_binary '',NULL,'2026-02-06 14:38:18.566119',NULL,'2026-02-06 14:39:25.537664','010-2930-1504','이기혁',NULL,'경북 구미시 3공단3로 302 한마음프라자',NULL,NULL,'kihyuk5566@naver.com',NULL,'$2a$10$KBGTgNwwnEkimxFDHGMPg.hX/CfuF2C7rajXS5s2E8zuliF4xU/XK','profile/taejeon_default_image.png','M');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-09  9:35:14
