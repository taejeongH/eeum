-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: eeum-rds.cvmcs64e0y2c.ap-northeast-2.rds.amazonaws.com    Database: eeum_db
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `sensor_events`
--

DROP TABLE IF EXISTS `sensor_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sensor_events` (
  `device_id` int NOT NULL,
  `group_id` int NOT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `processed` bit(1) NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `detected_at` datetime(6) NOT NULL,
  `started_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `kind` varchar(20) DEFAULT NULL,
  `event_type` varchar(30) NOT NULL,
  `location` varchar(50) DEFAULT NULL,
  `serial_number` varchar(100) DEFAULT NULL,
  `event_id` varchar(200) DEFAULT NULL,
  `event_data` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKmx3dfwblvd8ksmcaqv4aapxno` (`event_id`),
  KEY `FKh3xgi79ebp140qfjdb1jcx5nf` (`device_id`),
  KEY `FKi2o6d16yuvwquktu9qo76w75b` (`group_id`),
  CONSTRAINT `FKh3xgi79ebp140qfjdb1jcx5nf` FOREIGN KEY (`device_id`) REFERENCES `iot_devices` (`id`),
  CONSTRAINT `FKi2o6d16yuvwquktu9qo76w75b` FOREIGN KEY (`group_id`) REFERENCES `family_groups` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sensor_events`
--

LOCK TABLES `sensor_events` WRITE;
/*!40000 ALTER TABLE `sensor_events` DISABLE KEYS */;
INSERT INTO `sensor_events` VALUES (1,1,1,_binary '\0','2026-02-05 15:09:49.554883','2026-02-05 14:22:54.150000','2026-02-05 14:20:54.150000','2026-02-05 15:09:49.554883','vision','absence','','EEUM-J105','EEUM-J105_d3889998-88fb-496f-bfdb-7997fd9e9814','{\"kind\": \"vision\", \"serial_number\": \"EEUM-J105\", \"event\": \"absence\", \"started_at\": 1770268854.1500423, \"detected_at\": 1770268974.1508856, \"token\": \"eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJHUk9VUDoxIiwiaWQiOjAsImF1dGgiOiJST0xFX0RFVklDRSIsImlhdCI6MTc3MDI3MTE3OSwiZXhwIjoxODAxODA3MTc5LCJncm91cF9pZCI6MX0.DnelzhTOmTnwd32rj6Y9Gjy7r1UBtuKAsSgA2iRwNsUj96O0jPVMXTWvBLzdk5rPnP01ZW79swm0u9vwO_CVGwVpPUqoKG4KcHQXJULyFNDXXn3zYkTC8KHg43pyrJd2clEG6iMZFC73fdhbsmp7DCAQG410kgLhGL7COr9kRLkHC_SopcItkMXP6aJxof26EorDiUKMB1_hclRET4nMUIqJBJMMpQQDkxRCdAbZi3z9uwwoQo0Lp2FDY_aXVUk_1DkHuXipPNZUsynXYOjfz8_ZVIPlbRv7Sn4P3fn5Bpj-T7rMvDbrcjFB8EguRlLn-hqQnz1UiGKoROZW08vh3g\", \"msg_id\": \"d3889998-88fb-496f-bfdb-7997fd9e9814\"}'),(1,1,2,_binary '\0','2026-02-05 15:37:09.505592','2026-02-05 14:50:14.115000','2026-02-05 14:48:14.114000','2026-02-05 15:37:09.505592','vision','absence','','EEUM-J105','EEUM-J105_065a118b-e98a-4595-8a72-5c2ba546c7e5','{\"kind\": \"vision\", \"serial_number\": \"EEUM-J105\", \"event\": \"absence\", \"started_at\": 1770270494.1144261, \"detected_at\": 1770270614.1154451, \"token\": \"eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJHUk9VUDoxIiwiaWQiOjAsImF1dGgiOiJST0xFX0RFVklDRSIsImlhdCI6MTc3MDI3MTE3OSwiZXhwIjoxODAxODA3MTc5LCJncm91cF9pZCI6MX0.DnelzhTOmTnwd32rj6Y9Gjy7r1UBtuKAsSgA2iRwNsUj96O0jPVMXTWvBLzdk5rPnP01ZW79swm0u9vwO_CVGwVpPUqoKG4KcHQXJULyFNDXXn3zYkTC8KHg43pyrJd2clEG6iMZFC73fdhbsmp7DCAQG410kgLhGL7COr9kRLkHC_SopcItkMXP6aJxof26EorDiUKMB1_hclRET4nMUIqJBJMMpQQDkxRCdAbZi3z9uwwoQo0Lp2FDY_aXVUk_1DkHuXipPNZUsynXYOjfz8_ZVIPlbRv7Sn4P3fn5Bpj-T7rMvDbrcjFB8EguRlLn-hqQnz1UiGKoROZW08vh3g\", \"msg_id\": \"065a118b-e98a-4595-8a72-5c2ba546c7e5\"}'),(1,1,3,_binary '\0','2026-02-05 15:39:23.865014','2026-02-05 14:52:28.475000','2026-02-05 14:50:28.475000','2026-02-05 15:39:23.865014','vision','absence','','EEUM-J105','EEUM-J105_fe8c1c9f-fe3d-4408-99ec-ea363657589d','{\"kind\": \"vision\", \"serial_number\": \"EEUM-J105\", \"event\": \"absence\", \"started_at\": 1770270628.4750576, \"detected_at\": 1770270748.4755974, \"token\": \"eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJHUk9VUDoxIiwiaWQiOjAsImF1dGgiOiJST0xFX0RFVklDRSIsImlhdCI6MTc3MDI3MTE3OSwiZXhwIjoxODAxODA3MTc5LCJncm91cF9pZCI6MX0.DnelzhTOmTnwd32rj6Y9Gjy7r1UBtuKAsSgA2iRwNsUj96O0jPVMXTWvBLzdk5rPnP01ZW79swm0u9vwO_CVGwVpPUqoKG4KcHQXJULyFNDXXn3zYkTC8KHg43pyrJd2clEG6iMZFC73fdhbsmp7DCAQG410kgLhGL7COr9kRLkHC_SopcItkMXP6aJxof26EorDiUKMB1_hclRET4nMUIqJBJMMpQQDkxRCdAbZi3z9uwwoQo0Lp2FDY_aXVUk_1DkHuXipPNZUsynXYOjfz8_ZVIPlbRv7Sn4P3fn5Bpj-T7rMvDbrcjFB8EguRlLn-hqQnz1UiGKoROZW08vh3g\", \"msg_id\": \"fe8c1c9f-fe3d-4408-99ec-ea363657589d\"}'),(3,1,4,_binary '\0','2026-02-05 18:11:51.878703','2026-02-05 18:11:51.681000','2026-02-05 18:07:51.680000','2026-02-05 18:11:51.878703','pir','no_motion','','EEUM-E105-1','EEUM-E105-1_18a5fe58-83ef-4363-8db4-ff64c81790c4','{\"kind\": \"pir\", \"serial_number\": \"EEUM-E105-1\", \"event\": \"no_motion\", \"started_at\": 1770282471.6809516, \"detected_at\": 1770282711.6819556, \"token\": \"eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJHUk9VUDoxIiwiaWQiOjAsImF1dGgiOiJST0xFX0RFVklDRSIsImlhdCI6MTc3MDI3MTE3OSwiZXhwIjoxODAxODA3MTc5LCJncm91cF9pZCI6MX0.DnelzhTOmTnwd32rj6Y9Gjy7r1UBtuKAsSgA2iRwNsUj96O0jPVMXTWvBLzdk5rPnP01ZW79swm0u9vwO_CVGwVpPUqoKG4KcHQXJULyFNDXXn3zYkTC8KHg43pyrJd2clEG6iMZFC73fdhbsmp7DCAQG410kgLhGL7COr9kRLkHC_SopcItkMXP6aJxof26EorDiUKMB1_hclRET4nMUIqJBJMMpQQDkxRCdAbZi3z9uwwoQo0Lp2FDY_aXVUk_1DkHuXipPNZUsynXYOjfz8_ZVIPlbRv7Sn4P3fn5Bpj-T7rMvDbrcjFB8EguRlLn-hqQnz1UiGKoROZW08vh3g\", \"msg_id\": \"18a5fe58-83ef-4363-8db4-ff64c81790c4\"}'),(3,1,5,_binary '\0','2026-02-05 18:27:26.429446','2026-02-05 18:27:26.175000','2026-02-05 18:23:26.173000','2026-02-05 18:27:26.429446','pir','no_motion','','EEUM-E105-1','EEUM-E105-1_012cdea5-ff30-403b-a9ee-7fa408d00743','{\"kind\": \"pir\", \"serial_number\": \"EEUM-E105-1\", \"event\": \"no_motion\", \"started_at\": 1770283406.1739204, \"detected_at\": 1770283646.1752105, \"token\": \"eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJHUk9VUDoxIiwiaWQiOjAsImF1dGgiOiJST0xFX0RFVklDRSIsImlhdCI6MTc3MDI3MTE3OSwiZXhwIjoxODAxODA3MTc5LCJncm91cF9pZCI6MX0.DnelzhTOmTnwd32rj6Y9Gjy7r1UBtuKAsSgA2iRwNsUj96O0jPVMXTWvBLzdk5rPnP01ZW79swm0u9vwO_CVGwVpPUqoKG4KcHQXJULyFNDXXn3zYkTC8KHg43pyrJd2clEG6iMZFC73fdhbsmp7DCAQG410kgLhGL7COr9kRLkHC_SopcItkMXP6aJxof26EorDiUKMB1_hclRET4nMUIqJBJMMpQQDkxRCdAbZi3z9uwwoQo0Lp2FDY_aXVUk_1DkHuXipPNZUsynXYOjfz8_ZVIPlbRv7Sn4P3fn5Bpj-T7rMvDbrcjFB8EguRlLn-hqQnz1UiGKoROZW08vh3g\", \"msg_id\": \"012cdea5-ff30-403b-a9ee-7fa408d00743\"}'),(1,1,6,_binary '\0','2026-02-06 19:37:31.654336','2026-02-06 18:06:38.367000','2026-02-06 18:04:38.366000','2026-02-06 19:37:31.654336','vision','absence','','EEUM-J105','EEUM-J105_f7ba15bd-b937-46e8-96e6-484a3096d50d','{\"kind\": \"vision\", \"serial_number\": \"EEUM-J105\", \"event\": \"absence\", \"started_at\": 1770368678.3669822, \"detected_at\": 1770368798.3677807, \"token\": \"eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJHUk9VUDoxIiwiaWQiOjAsImF1dGgiOiJST0xFX0RFVklDRSIsImlhdCI6MTc3MDI3MTE3OSwiZXhwIjoxODAxODA3MTc5LCJncm91cF9pZCI6MX0.DnelzhTOmTnwd32rj6Y9Gjy7r1UBtuKAsSgA2iRwNsUj96O0jPVMXTWvBLzdk5rPnP01ZW79swm0u9vwO_CVGwVpPUqoKG4KcHQXJULyFNDXXn3zYkTC8KHg43pyrJd2clEG6iMZFC73fdhbsmp7DCAQG410kgLhGL7COr9kRLkHC_SopcItkMXP6aJxof26EorDiUKMB1_hclRET4nMUIqJBJMMpQQDkxRCdAbZi3z9uwwoQo0Lp2FDY_aXVUk_1DkHuXipPNZUsynXYOjfz8_ZVIPlbRv7Sn4P3fn5Bpj-T7rMvDbrcjFB8EguRlLn-hqQnz1UiGKoROZW08vh3g\", \"msg_id\": \"f7ba15bd-b937-46e8-96e6-484a3096d50d\"}'),(1,1,7,_binary '\0','2026-02-06 20:55:04.798705','2026-02-06 19:24:11.511000','2026-02-06 19:22:11.509000','2026-02-06 20:55:04.798705','vision','absence','','EEUM-J105','EEUM-J105_7606a3f6-3f3b-43a9-9f2f-b451046d3247','{\"kind\": \"vision\", \"serial_number\": \"EEUM-J105\", \"event\": \"absence\", \"started_at\": 1770373331.5090718, \"detected_at\": 1770373451.5115569, \"token\": \"eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJHUk9VUDoxIiwiaWQiOjAsImF1dGgiOiJST0xFX0RFVklDRSIsImlhdCI6MTc3MDI3MTE3OSwiZXhwIjoxODAxODA3MTc5LCJncm91cF9pZCI6MX0.DnelzhTOmTnwd32rj6Y9Gjy7r1UBtuKAsSgA2iRwNsUj96O0jPVMXTWvBLzdk5rPnP01ZW79swm0u9vwO_CVGwVpPUqoKG4KcHQXJULyFNDXXn3zYkTC8KHg43pyrJd2clEG6iMZFC73fdhbsmp7DCAQG410kgLhGL7COr9kRLkHC_SopcItkMXP6aJxof26EorDiUKMB1_hclRET4nMUIqJBJMMpQQDkxRCdAbZi3z9uwwoQo0Lp2FDY_aXVUk_1DkHuXipPNZUsynXYOjfz8_ZVIPlbRv7Sn4P3fn5Bpj-T7rMvDbrcjFB8EguRlLn-hqQnz1UiGKoROZW08vh3g\", \"msg_id\": \"7606a3f6-3f3b-43a9-9f2f-b451046d3247\"}'),(1,1,8,_binary '\0','2026-02-06 21:53:48.905268','2026-02-06 21:53:48.872000','2026-02-06 21:51:48.871000','2026-02-06 21:53:48.905268','vision','absence','','EEUM-J105','EEUM-J105_15206e79-50f1-480b-b7ba-5ab0685557bf','{\"kind\": \"vision\", \"serial_number\": \"EEUM-J105\", \"event\": \"absence\", \"started_at\": 1770382308.871375, \"detected_at\": 1770382428.872836, \"token\": \"eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJHUk9VUDoxIiwiaWQiOjAsImF1dGgiOiJST0xFX0RFVklDRSIsImlhdCI6MTc3MDI3MTE3OSwiZXhwIjoxODAxODA3MTc5LCJncm91cF9pZCI6MX0.DnelzhTOmTnwd32rj6Y9Gjy7r1UBtuKAsSgA2iRwNsUj96O0jPVMXTWvBLzdk5rPnP01ZW79swm0u9vwO_CVGwVpPUqoKG4KcHQXJULyFNDXXn3zYkTC8KHg43pyrJd2clEG6iMZFC73fdhbsmp7DCAQG410kgLhGL7COr9kRLkHC_SopcItkMXP6aJxof26EorDiUKMB1_hclRET4nMUIqJBJMMpQQDkxRCdAbZi3z9uwwoQo0Lp2FDY_aXVUk_1DkHuXipPNZUsynXYOjfz8_ZVIPlbRv7Sn4P3fn5Bpj-T7rMvDbrcjFB8EguRlLn-hqQnz1UiGKoROZW08vh3g\", \"msg_id\": \"15206e79-50f1-480b-b7ba-5ab0685557bf\"}'),(1,1,9,_binary '\0','2026-02-07 21:15:12.664359','2026-02-07 21:15:12.600000','2026-02-07 21:13:12.598000','2026-02-07 21:15:12.664359','vision','absence','','EEUM-J105','EEUM-J105_1e2f94f8-0fc3-4d6b-aed7-181603076745','{\"kind\": \"vision\", \"serial_number\": \"EEUM-J105\", \"event\": \"absence\", \"started_at\": 1770466392.5986328, \"detected_at\": 1770466512.6007636, \"token\": \"eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJHUk9VUDoxIiwiaWQiOjAsImF1dGgiOiJST0xFX0RFVklDRSIsImlhdCI6MTc3MDI3MTE3OSwiZXhwIjoxODAxODA3MTc5LCJncm91cF9pZCI6MX0.DnelzhTOmTnwd32rj6Y9Gjy7r1UBtuKAsSgA2iRwNsUj96O0jPVMXTWvBLzdk5rPnP01ZW79swm0u9vwO_CVGwVpPUqoKG4KcHQXJULyFNDXXn3zYkTC8KHg43pyrJd2clEG6iMZFC73fdhbsmp7DCAQG410kgLhGL7COr9kRLkHC_SopcItkMXP6aJxof26EorDiUKMB1_hclRET4nMUIqJBJMMpQQDkxRCdAbZi3z9uwwoQo0Lp2FDY_aXVUk_1DkHuXipPNZUsynXYOjfz8_ZVIPlbRv7Sn4P3fn5Bpj-T7rMvDbrcjFB8EguRlLn-hqQnz1UiGKoROZW08vh3g\", \"msg_id\": \"1e2f94f8-0fc3-4d6b-aed7-181603076745\"}'),(1,1,11,_binary '\0','2026-02-07 21:24:32.545832','2026-02-07 21:24:32.490000','2026-02-07 21:22:32.489000','2026-02-07 21:24:32.545832','vision','absence','','EEUM-J105','EEUM-J105_279fe280-00f6-4e86-a78a-21effdcf2b56','{\"kind\": \"vision\", \"serial_number\": \"EEUM-J105\", \"event\": \"absence\", \"started_at\": 1770466952.4890344, \"detected_at\": 1770467072.4903345, \"token\": \"eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJHUk9VUDoxIiwiaWQiOjAsImF1dGgiOiJST0xFX0RFVklDRSIsImlhdCI6MTc3MDI3MTE3OSwiZXhwIjoxODAxODA3MTc5LCJncm91cF9pZCI6MX0.DnelzhTOmTnwd32rj6Y9Gjy7r1UBtuKAsSgA2iRwNsUj96O0jPVMXTWvBLzdk5rPnP01ZW79swm0u9vwO_CVGwVpPUqoKG4KcHQXJULyFNDXXn3zYkTC8KHg43pyrJd2clEG6iMZFC73fdhbsmp7DCAQG410kgLhGL7COr9kRLkHC_SopcItkMXP6aJxof26EorDiUKMB1_hclRET4nMUIqJBJMMpQQDkxRCdAbZi3z9uwwoQo0Lp2FDY_aXVUk_1DkHuXipPNZUsynXYOjfz8_ZVIPlbRv7Sn4P3fn5Bpj-T7rMvDbrcjFB8EguRlLn-hqQnz1UiGKoROZW08vh3g\", \"msg_id\": \"279fe280-00f6-4e86-a78a-21effdcf2b56\"}');
/*!40000 ALTER TABLE `sensor_events` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-09  9:35:13
