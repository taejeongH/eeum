-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: eeum-rds.cvmcs64e0y2c.ap-northeast-2.rds.amazonaws.com    Database: eeum_db
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages` (
  `group_id` int NOT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `is_read` bit(1) DEFAULT NULL,
  `is_synced` bit(1) NOT NULL,
  `sender_user_id` int NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `read_at` datetime(6) DEFAULT NULL,
  `content` text NOT NULL,
  `voice_url` text,
  `voice_task_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKr8nvxnwuhk6un6y3e9lcjsme` (`voice_task_id`),
  KEY `FKah930rhky8pgao508llbbuswr` (`group_id`),
  KEY `FKk4mpqp6gfuaelpcamqv01brkr` (`sender_user_id`),
  CONSTRAINT `FK190tmt1j91gxdt9emqoouelpw` FOREIGN KEY (`voice_task_id`) REFERENCES `voice_tasks` (`id`),
  CONSTRAINT `FKah930rhky8pgao508llbbuswr` FOREIGN KEY (`group_id`) REFERENCES `family_groups` (`id`),
  CONSTRAINT `FKk4mpqp6gfuaelpcamqv01brkr` FOREIGN KEY (`sender_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` VALUES (1,107,_binary '\0',_binary '\0',7,'2026-02-08 21:18:21.124570',NULL,NULL,'엄마 요즘 독감 유행이래요~~ 어디 나가실 때 마스크 꼭 쓰고 나가세요!!','generated/7/e2116b7d-a5aa-4351-98e6-a141d72dd5ca.wav',150),(1,110,_binary '\0',_binary '\0',2,'2026-02-08 22:59:57.300387',NULL,NULL,'할머니 보고싶어요','generated/2/29cabf02-5b92-4569-a6f2-4e77d73b94a0.wav',153),(1,111,_binary '\0',_binary '\0',9,'2026-02-08 23:11:38.248421',NULL,NULL,'오늘 날씨가 추울수도 있으니 저번에 산 패딩 챙기시면 좋아요!','generated/9/23593b58-d5f1-478e-a821-85290343af0b.wav',154),(1,112,_binary '\0',_binary '\0',9,'2026-02-08 23:12:08.575535',NULL,NULL,'내일 날씨가 추우니 옷 챙겨입으세요!','generated/9/d9427b0e-c1af-43ab-9231-eb3920884288.wav',155),(1,115,_binary '\0',_binary '\0',1,'2026-02-08 23:45:52.132084',NULL,NULL,'엄마 약은 잘 챙겨 먹었어?\n내일 아침에 한 번 들릴게~~~','generated/1/d134bd94-3a3b-4640-8dba-709e43044966.wav',160),(1,116,_binary '\0',_binary '\0',7,'2026-02-09 08:34:06.118558',NULL,NULL,'엄마 오늘 춥대요ㅠ','generated/7/4fc8d04e-c935-4fda-8c0b-d76c4f856ea0.wav',161),(1,117,_binary '\0',_binary '\0',9,'2026-02-09 08:35:37.593718',NULL,NULL,'오늘부터 입추시작이래요!','generated/9/6f244f2c-2bed-49a2-bd10-3784d3faabca.wav',162);
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-09  9:35:15
