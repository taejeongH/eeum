-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: eeum-rds.cvmcs64e0y2c.ap-northeast-2.rds.amazonaws.com    Database: eeum_db
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `media_assets`
--

DROP TABLE IF EXISTS `media_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_assets` (
  `group_id` int NOT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `is_synced` bit(1) NOT NULL,
  `taken_at` date DEFAULT NULL,
  `uploader_user_id` int NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `description` text,
  `storage_url` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK4i5p18oli1vih5yjntfw94jvf` (`group_id`),
  KEY `FKo3ndchc2trlbblk6e5lxsuq6j` (`uploader_user_id`),
  CONSTRAINT `FK4i5p18oli1vih5yjntfw94jvf` FOREIGN KEY (`group_id`) REFERENCES `family_groups` (`id`),
  CONSTRAINT `FKo3ndchc2trlbblk6e5lxsuq6j` FOREIGN KEY (`uploader_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_assets`
--

LOCK TABLES `media_assets` WRITE;
/*!40000 ALTER TABLE `media_assets` DISABLE KEYS */;
INSERT INTO `media_assets` VALUES (2,1,_binary '\0','2026-02-05',3,'2026-02-05 14:13:17.171484','2026-02-05 14:13:17.171484','다운로드.jpg','album/40499848-9fec-493c-b460-68079b3b2023-다운로드.jpg'),(1,3,_binary '\0','2026-02-05',3,'2026-02-05 16:24:24.788482','2026-02-06 17:52:23.694242','풍경 사진','album/37370644-1f97-4577-babb-748b7c7f48ed-3d-sunset-landscape-with-cherry-tree-against-sunset-sky.jpg'),(1,4,_binary '\0','2026-02-05',3,'2026-02-05 16:24:34.716396','2026-02-06 17:52:50.129019','하늘 사진','album/6b0fc1c6-ac6f-490a-89b6-e4eb129c7ab3-3d-render-coastal-landscape-sunset-sky.jpg'),(1,5,_binary '\0','2026-02-05',3,'2026-02-05 16:24:40.615368','2026-02-06 17:53:22.509198','강가 사진','album/d9865fd1-dea6-44e8-9500-34658d0a9485-lake-kawaguchiko.jpg'),(7,10,_binary '\0','2026-02-06',4,'2026-02-06 19:38:06.187500','2026-02-06 19:39:17.206248','알림 할게요','album/f3567b13-b121-49db-8292-407af2864fc5-Screenshot_20260203_175509_eeum.jpg'),(1,11,_binary '\0','2026-02-06',9,'2026-02-06 20:08:02.309626','2026-02-06 20:08:02.309626','재밌게 놀고 있어요!','album/10a4ffb9-bc0d-4494-b646-752f37a17248-20210719_182650.jpg'),(1,12,_binary '\0','2026-02-07',9,'2026-02-07 12:19:57.133701','2026-02-07 12:19:57.133701','상하이의 아침','album/91ab4997-8a8e-4fc9-ac53-de7c72360e7c-1770434360633.jpg'),(1,13,_binary '\0','2026-02-07',9,'2026-02-07 12:20:36.902955','2026-02-07 12:20:36.902955','행복한 광화문, 순수한 마음','album/b9b37c86-9d08-4f99-a316-a4890bd8a90e-1770434361908.jpg'),(1,14,_binary '\0','2026-02-07',9,'2026-02-07 12:20:55.726225','2026-02-07 12:20:55.726225','넓은 바다로...','album/cd011ae5-d605-4b33-b914-652d14003db7-1770434361651.jpg'),(1,15,_binary '\0','2026-02-07',9,'2026-02-07 12:21:16.886364','2026-02-07 12:21:16.886364','다홍 노을','album/6b02cc77-116e-4d26-b9d2-85a3dbb1f601-1770434362378.jpg'),(1,16,_binary '\0','2026-02-07',9,'2026-02-07 12:21:34.436600','2026-02-07 12:21:34.436600','붕어붕어 금붕어','album/315d05dd-e91b-4374-81bc-224d9ee8af85-1770434362595.jpg'),(1,17,_binary '\0','2026-02-07',9,'2026-02-07 12:21:57.759366','2026-02-07 12:21:57.759366','눈 내린 산위 눈오리','album/3bcb58f1-6c7a-4aa5-99cb-5b461026a96a-1770434363016.jpg'),(1,18,_binary '\0','2026-02-07',9,'2026-02-07 12:22:22.670131','2026-02-07 12:22:22.670131','계단식 빌딩','album/e6563843-db52-4562-aea9-5ae5f3be4083-1770434362147.jpg'),(1,19,_binary '\0','2026-02-07',9,'2026-02-07 12:22:47.176455','2026-02-07 12:22:47.176455','1000개의 나무 건축','album/0a226c96-bd16-4abb-af94-7f05dcb4d630-1770434361428.jpg'),(1,20,_binary '\0','2026-02-07',9,'2026-02-07 12:23:01.827310','2026-02-07 12:23:01.827310','벽과 선','album/2c425210-2f89-4358-9174-dcb2cf428c06-1770434361191.jpg'),(1,24,_binary '\0','2026-02-07',1,'2026-02-07 14:20:11.714613','2026-02-07 14:20:11.714613','신기한 신기마을','album/be996a59-1a4a-4bac-922c-34cf3f51adbe-IMG_6991.jpeg'),(1,25,_binary '\0','2026-02-07',1,'2026-02-07 14:21:07.862173','2026-02-07 14:21:07.862173','산타다 한컷 ㅎ','album/a3bf9e15-87dd-4c2f-a8b4-1b9f2832d3ed-IMG_6907.jpeg'),(1,26,_binary '\0','2026-02-07',1,'2026-02-07 14:22:00.444607','2026-02-07 14:22:00.444607','경치조타~~~~~~ㅋ','album/348340c4-29a4-46a6-9922-6f8175abd509-IMG_5669.jpeg'),(1,27,_binary '\0','2026-02-07',9,'2026-02-07 17:33:43.846294','2026-02-07 17:33:43.846294','노을이 너무 이뻐요','album/6cb03931-0477-4d34-baba-d2502fc87e3e-1770453194726.jpg'),(1,28,_binary '\0','2026-02-07',7,'2026-02-07 17:33:57.164847','2026-02-07 17:33:57.164847','달 달 무슨 달 쟁반 같이 둥근 달','album/e6ad1c98-7f0a-49a2-9d54-fa9bc61cdb3a-3304.jpg'),(1,36,_binary '\0','2026-02-08',1,'2026-02-09 07:55:18.230172','2026-02-09 07:55:18.230172','저번 가족여행 때 사진~~^^','album/7d5e7b67-98c9-4d71-b228-4b3612450526-IMG_7214.jpeg'),(1,37,_binary '\0','2026-02-08',1,'2026-02-09 07:55:18.237747','2026-02-09 07:55:18.237747','저번 가족여행 때 사진~~^^','album/06805f6c-5127-413b-a0c5-6772e270a1dd-IMG_7203.jpeg'),(1,38,_binary '\0','2026-02-08',1,'2026-02-09 07:55:18.240901','2026-02-09 07:55:18.240901','저번 가족여행 때 사진~~^^','album/616b5bfe-6f01-4ac1-b7ee-c1407650b8c9-IMG_7204.jpeg'),(1,39,_binary '\0','2026-02-08',1,'2026-02-09 07:55:18.243134','2026-02-09 07:55:18.243134','저번 가족여행 때 사진~~^^','album/55c2fa7d-3874-422e-a931-85fa43c68665-IMG_7153.jpeg'),(1,40,_binary '\0','2026-02-08',1,'2026-02-09 07:55:18.245097','2026-02-09 07:55:18.245097','저번 가족여행 때 사진~~^^','album/145c8183-162c-492d-8538-98d9d624ea5f-IMG_7146.jpeg'),(1,41,_binary '\0','2026-02-08',1,'2026-02-09 07:55:18.247657','2026-02-09 07:55:18.247657','저번 가족여행 때 사진~~^^','album/0f306955-6454-401c-aac7-82e79638bb7f-IMG_7117.jpeg'),(1,42,_binary '\0','2026-02-08',1,'2026-02-09 07:55:18.250305','2026-02-09 07:55:18.250305','저번 가족여행 때 사진~~^^','album/24c0aa56-48c0-489a-afa8-93404aa49f3a-IMG_7102.jpeg'),(1,43,_binary '\0','2026-02-08',1,'2026-02-09 07:55:18.253205','2026-02-09 07:55:18.253205','저번 가족여행 때 사진~~^^','album/3e2c1fa5-3489-4b68-b3b8-5eb5ace26eb1-IMG_6702.jpeg');
/*!40000 ALTER TABLE `media_assets` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-09  9:35:21
