-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: eeum-rds.cvmcs64e0y2c.ap-northeast-2.rds.amazonaws.com    Database: eeum_db
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `supporters`
--

DROP TABLE IF EXISTS `supporters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supporters` (
  `emergency_priority` int DEFAULT NULL,
  `group_id` int NOT NULL,
  `representative_flag` bit(1) NOT NULL,
  `user_id` int NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `joined_at` datetime(6) DEFAULT NULL,
  `relationship` varchar(255) DEFAULT NULL,
  `role` enum('CAREGIVER','PATIENT') NOT NULL,
  PRIMARY KEY (`group_id`,`user_id`),
  KEY `FKrb1mysx0xjbvhtfln8o2482cc` (`user_id`),
  CONSTRAINT `FK4aauh7mwnnfolnjdjs0t5pglo` FOREIGN KEY (`group_id`) REFERENCES `family_groups` (`id`),
  CONSTRAINT `FKrb1mysx0xjbvhtfln8o2482cc` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supporters`
--

LOCK TABLES `supporters` WRITE;
/*!40000 ALTER TABLE `supporters` DISABLE KEYS */;
INSERT INTO `supporters` VALUES (3,1,_binary '\0',1,NULL,'2026-02-05 12:52:44.296555',NULL,'CAREGIVER'),(2,1,_binary '',2,NULL,'2026-02-05 12:17:58.699421','손녀','CAREGIVER'),(NULL,1,_binary '\0',3,NULL,'2026-02-05 12:27:11.505929',NULL,'PATIENT'),(NULL,1,_binary '\0',6,NULL,'2026-02-05 13:10:18.269670',NULL,'CAREGIVER'),(NULL,1,_binary '\0',7,NULL,'2026-02-07 11:46:33.600238',NULL,'CAREGIVER'),(1,1,_binary '\0',9,NULL,'2026-02-06 14:55:42.418239',NULL,'CAREGIVER'),(NULL,2,_binary '\0',2,NULL,'2026-02-05 12:19:29.444740',NULL,'PATIENT'),(NULL,2,_binary '',3,NULL,'2026-02-05 12:19:29.444740','큰 아들','CAREGIVER'),(NULL,2,_binary '\0',7,NULL,'2026-02-05 12:19:29.444740',NULL,'CAREGIVER'),(3,3,_binary '\0',2,NULL,'2026-02-06 13:40:23.817344',NULL,'CAREGIVER'),(NULL,3,_binary '\0',3,NULL,'2026-02-06 13:51:33.452881',NULL,'PATIENT'),(2,3,_binary '\0',7,NULL,'2026-02-06 13:50:01.845789',NULL,'CAREGIVER'),(1,3,_binary '',9,NULL,'2026-02-06 13:28:18.131612','첫째 손주','CAREGIVER'),(NULL,4,_binary '',10,NULL,'2026-02-06 14:35:48.921421','팀장','CAREGIVER'),(NULL,5,_binary '',12,NULL,'2026-02-06 14:39:45.369164','용문','CAREGIVER'),(1,6,_binary '',3,NULL,'2026-02-06 18:10:46.943711',NULL,'CAREGIVER'),(1,7,_binary '\0',4,NULL,'2026-02-06 19:24:02.842651',NULL,'PATIENT'),(1,8,_binary '',1,NULL,'2026-02-06 21:12:35.461905',NULL,'CAREGIVER'),(NULL,8,_binary '\0',3,NULL,'2026-02-06 21:26:19.610079',NULL,'PATIENT');
/*!40000 ALTER TABLE `supporters` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-09  9:35:16
