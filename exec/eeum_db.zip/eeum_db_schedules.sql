-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: eeum-rds.cvmcs64e0y2c.ap-northeast-2.rds.amazonaws.com    Database: eeum_db
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `schedules`
--

DROP TABLE IF EXISTS `schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedules` (
  `creator_id` int NOT NULL,
  `group_id` int NOT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `is_lunar` bit(1) DEFAULT NULL,
  `is_visited` bit(1) DEFAULT NULL,
  `parent_id` int DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `end_at` datetime(6) NOT NULL,
  `recurrence_end_at` datetime(6) DEFAULT NULL,
  `start_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `title` varchar(100) NOT NULL,
  `description` text,
  `target_person` varchar(255) DEFAULT NULL,
  `visit_purpose` varchar(255) DEFAULT NULL,
  `visitor_name` varchar(255) DEFAULT NULL,
  `category_type` enum('ANNIVERSARY','BIRTHDAY','EVENT','MEDICAL','MEMORIAL','VISIT') NOT NULL,
  `repeat_type` enum('NONE','YEARLY') DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK5fdfkb63tc396imu98sypvpsd` (`creator_id`),
  KEY `FKffvv9w8072y2iob01ito50b14` (`group_id`),
  CONSTRAINT `FK5fdfkb63tc396imu98sypvpsd` FOREIGN KEY (`creator_id`) REFERENCES `users` (`id`),
  CONSTRAINT `FKffvv9w8072y2iob01ito50b14` FOREIGN KEY (`group_id`) REFERENCES `family_groups` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedules`
--

LOCK TABLES `schedules` WRITE;
/*!40000 ALTER TABLE `schedules` DISABLE KEYS */;
INSERT INTO `schedules` VALUES (3,1,1,_binary '\0',_binary '\0',NULL,'2026-02-05 12:36:59.075984','2026-09-16 13:00:00.000000',NULL,'2026-09-16 12:00:00.000000','2026-02-05 12:36:59.075984','이창민 생일','',NULL,NULL,NULL,'BIRTHDAY','YEARLY'),(3,1,2,_binary '\0',_binary '\0',NULL,'2026-02-05 12:38:55.379026','2027-12-29 13:00:00.000000',NULL,'2027-12-29 12:00:00.000000','2026-02-05 12:38:55.379026','손홍헌 생일','',NULL,NULL,NULL,'BIRTHDAY','YEARLY'),(4,1,4,_binary '\0',_binary '\0',NULL,'2026-02-05 19:09:19.369505','2026-02-16 13:00:00.000000',NULL,'2026-02-16 12:00:00.000000','2026-02-05 19:09:19.369505','구정(당일)','',NULL,NULL,NULL,'EVENT','NONE'),(4,1,5,_binary '\0',_binary '\0',NULL,'2026-02-05 19:10:09.067422','2026-02-05 13:00:00.000000',NULL,'2026-02-05 12:00:00.000000','2026-02-05 19:10:09.067422','홍헌 생일','종현아 생일축하해!',NULL,NULL,NULL,'BIRTHDAY','YEARLY'),(3,1,6,_binary '\0',_binary '\0',NULL,'2026-02-06 17:40:21.970943','2026-02-06 13:00:00.000000',NULL,'2026-02-06 12:00:00.000000','2026-02-06 17:40:21.970943','테스트','',NULL,NULL,NULL,'VISIT','NONE'),(4,7,7,_binary '\0',_binary '\0',NULL,'2026-02-06 19:54:43.210828','2026-02-07 13:00:00.000000',NULL,'2026-02-07 12:00:00.000000','2026-02-06 19:54:43.210828','adsp','가연님 화이팅',NULL,NULL,NULL,'EVENT','NONE'),(4,7,8,_binary '\0',_binary '\0',NULL,'2026-02-06 19:56:52.390582','2026-02-08 13:00:00.000000',NULL,'2026-02-08 12:00:00.000000','2026-02-06 19:56:52.390582','연등회','연등 집회 합니다',NULL,'연등 집회.','재웅','VISIT','YEARLY'),(2,1,9,_binary '\0',_binary '\0',NULL,'2026-02-08 16:44:38.499594','1998-02-14 10:00:00.000000',NULL,'1998-02-14 09:00:00.000000','2026-02-08 16:44:38.499594','허태정님의 생신','허태정님의 자동 등록된 생신 일정입니다.','허태정',NULL,NULL,'BIRTHDAY','YEARLY'),(9,1,10,_binary '\0',_binary '\0',NULL,'2026-02-08 23:13:57.751443','2026-02-10 13:00:00.000000',NULL,'2026-02-10 12:00:00.000000','2026-02-08 23:13:57.751443','어머니 건강검진','가톨릭병원 건강검진',NULL,NULL,NULL,'MEDICAL','NONE'),(9,1,11,_binary '\0',_binary '\0',NULL,'2026-02-09 08:03:49.839581','2026-02-09 13:00:00.000000',NULL,'2026-02-09 12:00:00.000000','2026-02-09 08:03:49.839581','가연이 생일','축하 메시지 보내주세요!',NULL,NULL,NULL,'EVENT','NONE');
/*!40000 ALTER TABLE `schedules` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-09  9:35:13
