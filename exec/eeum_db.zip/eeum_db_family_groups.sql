-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: eeum-rds.cvmcs64e0y2c.ap-northeast-2.rds.amazonaws.com    Database: eeum_db
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `family_groups`
--

DROP TABLE IF EXISTS `family_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `family_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `last_media_log_id` int NOT NULL,
  `last_voice_log_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `group_name` varchar(255) NOT NULL,
  `invite_code` varchar(255) DEFAULT NULL,
  `streaming_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKoexs8gfm9qosnc2yssjyx4nvq` (`invite_code`),
  KEY `FK4u9gdfoqdj8e2khcfwut76718` (`user_id`),
  CONSTRAINT `FK4u9gdfoqdj8e2khcfwut76718` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `family_groups`
--

LOCK TABLES `family_groups` WRITE;
/*!40000 ALTER TABLE `family_groups` DISABLE KEYS */;
INSERT INTO `family_groups` VALUES (1,0,0,2,'2026-02-05 12:17:58.673946','2026-02-07 15:14:28.763376','김옥순','EYP48FBX','http://10.25.185.238:8000/api/iot/device/falls/stream'),(2,0,0,3,'2026-02-05 12:19:29.438654','2026-02-05 12:19:29.438675','테스트','CY5QA5ZM','http://10.205.81.239:8000/api/iot/device/falls/stream'),(3,0,0,9,'2026-02-06 13:28:18.058336','2026-02-06 13:28:18.058394','사랑하는 우리 가족','L3JB235W','http://10.205.81.239:8000/api/iot/device/falls/stream'),(4,0,0,10,'2026-02-06 14:35:48.915623','2026-02-06 14:35:55.416357','D202','5MF3J8ST','http://10.205.81.239:8000/api/iot/device/falls/stream'),(5,0,0,12,'2026-02-06 14:39:45.364453','2026-02-06 14:39:45.364473','d202','7POJJYRZ','http://10.205.81.239:8000/api/iot/device/falls/stream'),(6,0,0,3,'2026-02-06 18:10:46.896011','2026-02-06 18:10:46.896083','테스트2','BNHXGKJH','http://10.205.81.239:8000/api/iot/device/falls/stream'),(7,0,0,4,'2026-02-06 19:24:02.823874','2026-02-06 19:30:30.957172','비버가족','U4N64YJY','http://10.205.81.239:8000/api/iot/device/falls/stream'),(8,0,0,1,'2026-02-06 21:12:34.699265','2026-02-06 21:12:34.699265','실시간테스트','E44A5TNT','http://10.205.81.239:8000/api/iot/device/falls/stream');
/*!40000 ALTER TABLE `family_groups` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-09  9:35:20
