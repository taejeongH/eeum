-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: eeum-rds.cvmcs64e0y2c.ap-northeast-2.rds.amazonaws.com    Database: eeum_db
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `test_table`
--

DROP TABLE IF EXISTS `test_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_table` (
  `heart_rate` int DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=138 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_table`
--

LOCK TABLES `test_table` WRITE;
/*!40000 ALTER TABLE `test_table` DISABLE KEYS */;
INSERT INTO `test_table` VALUES (94,1),(94,2),(94,3),(92,4),(90,5),(90,6),(89,7),(89,8),(90,9),(89,10),(88,11),(87,12),(87,13),(86,14),(86,15),(86,16),(86,17),(86,18),(87,19),(87,20),(87,21),(87,22),(87,23),(88,24),(87,25),(88,26),(90,27),(91,28),(91,29),(90,30),(96,31),(91,32),(89,33),(87,34),(90,35),(90,36),(89,37),(89,38),(89,39),(89,40),(89,41),(89,42),(89,43),(91,44),(92,45),(92,46),(92,47),(91,48),(90,49),(89,50),(83,51),(85,52),(85,53),(84,54),(84,55),(83,56),(83,57),(83,58),(83,59),(83,60),(83,61),(82,62),(83,63),(84,64),(83,65),(83,66),(84,67),(84,68),(84,69),(84,70),(84,71),(84,72),(84,73),(84,74),(84,75),(84,76),(84,77),(84,78),(84,79),(85,80),(92,81),(91,82),(92,83),(91,84),(91,85),(90,86),(91,87),(90,88),(90,89),(90,90),(90,91),(90,92),(90,93),(90,94),(90,95),(90,96),(90,97),(89,98),(89,99),(89,100),(89,101),(88,102),(87,103),(86,104),(85,105),(85,106),(86,107),(86,108),(86,109),(87,110),(87,111),(87,112),(88,113),(88,114),(88,115),(88,116),(89,117),(89,118),(88,119),(89,120),(89,121),(90,122),(90,123),(90,124),(91,125),(90,126),(90,127),(90,128),(90,129),(90,130),(90,131),(88,132),(88,133),(89,134),(90,135),(89,136),(89,137);
/*!40000 ALTER TABLE `test_table` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-09  9:35:19
