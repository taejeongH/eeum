-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: eeum-rds.cvmcs64e0y2c.ap-northeast-2.rds.amazonaws.com    Database: eeum_db
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `iot_notifications`
--

DROP TABLE IF EXISTS `iot_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `iot_notifications` (
  `group_id` int NOT NULL,
  `is_read` bit(1) NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `id` bigint NOT NULL AUTO_INCREMENT,
  `updated_at` datetime(6) DEFAULT NULL,
  `kind` varchar(30) NOT NULL,
  `message_id` varchar(100) NOT NULL,
  `serial_number` varchar(100) NOT NULL,
  `content` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKhr4inousgtiwd4lcd29nh66ya` (`message_id`),
  KEY `FKbd07r4pmks1khn9j6ifjlgafx` (`group_id`),
  CONSTRAINT `FKbd07r4pmks1khn9j6ifjlgafx` FOREIGN KEY (`group_id`) REFERENCES `family_groups` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iot_notifications`
--

LOCK TABLES `iot_notifications` WRITE;
/*!40000 ALTER TABLE `iot_notifications` DISABLE KEYS */;
INSERT INTO `iot_notifications` VALUES (1,_binary '\0','2026-02-05 20:00:00.707597',1,'2026-02-05 20:00:00.707597','schedule','ee79fab6-c621-484e-873f-c2c3d4bf1bc3','EEUM-J105','내일 예정된 일정이 없습니다.'),(1,_binary '\0','2026-02-05 20:00:00.946965',2,'2026-02-05 20:00:00.946965','schedule','1a1aa0ff-5d76-40e6-adfc-0301dd811c43','EEUM-R105','내일 예정된 일정이 없습니다.'),(1,_binary '\0','2026-02-05 20:00:00.600396',3,'2026-02-05 20:00:00.600396','schedule','e3c1ba75-8cbd-4809-90cf-dcf8d6a82eb1','EEUM-J105','내일 예정된 일정이 없습니다.'),(1,_binary '\0','2026-02-05 20:00:01.050830',4,'2026-02-05 20:00:01.050830','schedule','a2f9c5ac-75d4-4306-91d4-28a07fd87972','EEUM-E105-1','내일 예정된 일정이 없습니다.'),(1,_binary '\0','2026-02-05 20:00:01.020055',5,'2026-02-05 20:00:01.020055','schedule','49e9a772-1c2d-4feb-b263-2f5422b1b731','EEUM-R105','내일 예정된 일정이 없습니다.'),(1,_binary '\0','2026-02-05 20:00:01.055064',6,'2026-02-05 20:00:01.055064','schedule','5fe5a85c-3042-4ec0-9c61-abcd629c6193','EEUM-E105-1','내일 예정된 일정이 없습니다.'),(1,_binary '\0','2026-02-06 08:00:00.301463',7,'2026-02-06 08:00:00.301463','schedule','b5186617-2eac-4a03-add2-9a19898996f5','EEUM-J105','오늘 예정된 일정이 없습니다.'),(1,_binary '\0','2026-02-06 08:00:00.371382',8,'2026-02-06 08:00:00.371382','schedule','df61421c-bad0-46f4-9d37-8c0f966cda56','EEUM-R105','오늘 예정된 일정이 없습니다.'),(1,_binary '\0','2026-02-06 08:00:00.407217',9,'2026-02-06 08:00:00.407217','schedule','967a5665-1e4e-44ea-80be-de6974d5012a','EEUM-E105-1','오늘 예정된 일정이 없습니다.'),(1,_binary '\0','2026-02-06 20:00:00.042035',10,'2026-02-06 20:00:00.042035','schedule','2e3322f4-b6c7-476b-8b04-4b2fba648ff9','EEUM-J105','내일 예정된 일정이 없습니다.'),(1,_binary '\0','2026-02-06 20:00:00.690852',11,'2026-02-06 20:00:00.690852','schedule','6f20c686-2b32-40b0-bf45-33ae22d2269b','EEUM-R105','내일 예정된 일정이 없습니다.'),(1,_binary '\0','2026-02-06 20:00:00.998272',12,'2026-02-06 20:00:00.998272','schedule','d32cbcbc-1c89-4546-bc90-0ca806e20c44','EEUM-E105-1','내일 예정된 일정이 없습니다.'),(1,_binary '\0','2026-02-06 20:00:01.722459',13,'2026-02-06 20:00:01.722459','schedule','e9b59036-9e9f-4e2c-ac6f-bbd06ccbe2d9','EEUM-J105','내일 예정된 일정이 없습니다.'),(1,_binary '\0','2026-02-06 20:00:02.327654',14,'2026-02-06 20:00:02.327654','schedule','8c89aad8-2e64-41d1-a31a-bc4dbb5f5951','EEUM-R105','내일 예정된 일정이 없습니다.'),(1,_binary '\0','2026-02-06 20:00:02.499090',15,'2026-02-06 20:00:02.499090','schedule','0a7982da-5d01-4000-8ab0-8b0b658fd9fc','EEUM-E105-1','내일 예정된 일정이 없습니다.'),(1,_binary '\0','2026-02-07 08:00:00.457174',16,'2026-02-07 08:00:00.457174','schedule','6c175979-7935-472a-b0c7-561ba1b82d40','EEUM-J105','오늘 예정된 일정이 없습니다.'),(1,_binary '\0','2026-02-07 08:00:00.524398',17,'2026-02-07 08:00:00.524398','schedule','2996741c-2f36-43ca-943f-55d078dae499','EEUM-R105','오늘 예정된 일정이 없습니다.'),(1,_binary '\0','2026-02-07 08:00:00.555154',18,'2026-02-07 08:00:00.555154','schedule','26e70fc3-f762-4775-ade3-a447c3da9c72','EEUM-E105-1','오늘 예정된 일정이 없습니다.'),(1,_binary '\0','2026-02-07 10:49:42.278902',19,'2026-02-07 10:49:42.278902','schedule','6b5cb55a-eede-417d-b620-67c62ac4246d','EEUM-J105','오늘 예정된 일정이 없습니다.'),(1,_binary '\0','2026-02-07 10:49:42.331798',20,'2026-02-07 10:49:42.331798','schedule','b4cd2a6c-5227-486e-b0f2-e8e79bbf68a8','EEUM-R105','오늘 예정된 일정이 없습니다.'),(1,_binary '\0','2026-02-07 10:49:42.352339',21,'2026-02-07 10:49:42.352339','schedule','f7b6a944-4aaf-4807-ae0d-62caac61fdb2','EEUM-E105-1','오늘 예정된 일정이 없습니다.'),(1,_binary '\0','2026-02-07 20:00:00.681248',22,'2026-02-07 20:00:00.681248','schedule','d7035e4f-aafc-4cc7-a7e1-a367a08935a1','EEUM-J105','내일 예정된 일정이 없습니다.'),(1,_binary '\0','2026-02-07 20:00:00.733869',23,'2026-02-07 20:00:00.733869','schedule','6ae6abad-fcd5-49e5-9eb2-69942764654a','EEUM-R105','내일 예정된 일정이 없습니다.'),(1,_binary '\0','2026-02-07 20:00:00.759191',24,'2026-02-07 20:00:00.759191','schedule','cbb28cca-9c72-42b5-a55b-ee815b2acf3f','EEUM-E105-1','내일 예정된 일정이 없습니다.'),(8,_binary '\0','2026-02-07 20:00:01.306284',25,'2026-02-07 20:00:01.306284','schedule','f81a52db-c72d-4502-ad11-122dc636cdd0','EEUM-J1051','내일 예정된 일정이 없습니다.'),(1,_binary '\0','2026-02-08 08:00:00.333820',26,'2026-02-08 08:00:00.333820','schedule','c866bffa-d061-4c78-9bf6-a6c744dd8fa8','EEUM-J105','오늘 예정된 일정이 없습니다.'),(1,_binary '\0','2026-02-08 08:00:00.466234',27,'2026-02-08 08:00:00.466234','schedule','ce59fc52-d47f-47d7-a840-4539f2437771','EEUM-R105','오늘 예정된 일정이 없습니다.'),(1,_binary '\0','2026-02-08 08:00:00.507209',28,'2026-02-08 08:00:00.507209','schedule','521aa8a0-ac7c-4d0d-a747-c75076aabb28','EEUM-E105-1','오늘 예정된 일정이 없습니다.'),(8,_binary '\0','2026-02-08 08:00:00.837984',29,'2026-02-08 08:00:00.837984','schedule','44ac5ff4-8cc6-4721-bc98-fa061c51eb7d','EEUM-J1051','오늘 예정된 일정이 없습니다.'),(1,_binary '\0','2026-02-08 20:00:00.242318',30,'2026-02-08 20:00:00.242318','schedule','9050e2a0-321b-4975-8ee7-28e0eb80d5a9','EEUM-J105','내일 총 1개의 일정이 있습니다. 12:00, 최종 발표. '),(1,_binary '\0','2026-02-08 20:00:00.355781',31,'2026-02-08 20:00:00.355781','schedule','dcab84e9-cd6d-4cf4-b1f6-ae20b0df3cb2','EEUM-R105','내일 총 1개의 일정이 있습니다. 12:00, 최종 발표. '),(1,_binary '\0','2026-02-08 20:00:00.479662',32,'2026-02-08 20:00:00.479662','schedule','970b8522-87c4-42c8-962d-8ea9a54885fb','EEUM-E105-1','내일 총 1개의 일정이 있습니다. 12:00, 최종 발표. '),(1,_binary '\0','2026-02-08 20:00:00.523611',33,'2026-02-08 20:00:00.523611','schedule','ce05fd98-771f-46f8-bdc1-0aba269fb426','EEUM-J105','내일 총 1개의 일정이 있습니다. 12:00, 최종 발표. '),(1,_binary '\0','2026-02-08 20:00:00.646661',34,'2026-02-08 20:00:00.646661','schedule','3244b92a-e6e1-46e2-86de-ee4702d3b692','EEUM-R105','내일 총 1개의 일정이 있습니다. 12:00, 최종 발표. '),(1,_binary '\0','2026-02-08 20:00:00.694296',35,'2026-02-08 20:00:00.694296','schedule','275ef0b0-db63-48f1-8252-513027196650','EEUM-E105-1','내일 총 1개의 일정이 있습니다. 12:00, 최종 발표. '),(8,_binary '\0','2026-02-08 20:00:00.856374',36,'2026-02-08 20:00:00.856374','schedule','3a719cf5-60b5-4089-98ea-a13ac1a4cdcb','EEUM-J1051','내일 예정된 일정이 없습니다.'),(8,_binary '\0','2026-02-08 20:00:01.163553',37,'2026-02-08 20:00:01.163553','schedule','fcae886f-d731-47d1-a32c-c33015c3b6c7','EEUM-J1051','내일 예정된 일정이 없습니다.'),(1,_binary '\0','2026-02-09 08:00:00.566723',38,'2026-02-09 08:00:00.566723','schedule','4926f550-ef36-4f65-b7b1-596ee0363170','EEUM-J105','오늘 총 1개의 일정이 있습니다. 12:00, 최종 발표. '),(1,_binary '\0','2026-02-09 08:00:00.708403',39,'2026-02-09 08:00:00.708403','schedule','69615873-c170-42eb-a4f9-118941423b3d','EEUM-R105','오늘 총 1개의 일정이 있습니다. 12:00, 최종 발표. '),(1,_binary '\0','2026-02-09 08:00:00.925111',40,'2026-02-09 08:00:00.925111','schedule','413049ec-0b9c-45e8-9dbc-02c151b3a23f','EEUM-E105-1','오늘 총 1개의 일정이 있습니다. 12:00, 최종 발표. '),(8,_binary '\0','2026-02-09 08:00:01.283166',41,'2026-02-09 08:00:01.283166','schedule','49db4cb2-cb03-43b3-889c-4dd331735a4b','EEUM-J1051','오늘 예정된 일정이 없습니다.');
/*!40000 ALTER TABLE `iot_notifications` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-09  9:35:20
