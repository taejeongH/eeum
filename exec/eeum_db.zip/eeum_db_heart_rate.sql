-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: eeum-rds.cvmcs64e0y2c.ap-northeast-2.rds.amazonaws.com    Database: eeum_db
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `heart_rate`
--

DROP TABLE IF EXISTS `heart_rate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `heart_rate` (
  `id` int NOT NULL AUTO_INCREMENT,
  `min_rate` int NOT NULL,
  `max_rate` int NOT NULL,
  `avg_rate` int NOT NULL,
  `measured_at` datetime NOT NULL,
  `group_id` int NOT NULL,
  `related_id` int DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_heart_rate_fall_event` (`related_id`),
  KEY `fk_heart_rate_family_group` (`group_id`),
  CONSTRAINT `fk_heart_rate_fall_event` FOREIGN KEY (`related_id`) REFERENCES `fall_events` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_heart_rate_family_group` FOREIGN KEY (`group_id`) REFERENCES `family_groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `heart_rate`
--

LOCK TABLES `heart_rate` WRITE;
/*!40000 ALTER TABLE `heart_rate` DISABLE KEYS */;
INSERT INTO `heart_rate` VALUES (55,87,93,90,'2026-02-05 14:49:03',1,NULL,'2026-02-05 14:49:03'),(56,80,85,83,'2026-02-05 16:54:32',1,NULL,'2026-02-05 16:54:31'),(57,97,98,97,'2026-02-06 13:33:06',1,NULL,'2026-02-06 13:33:06'),(58,94,97,95,'2026-02-06 14:32:36',1,NULL,'2026-02-06 14:32:35'),(59,91,98,93,'2026-02-06 14:42:34',1,NULL,'2026-02-06 14:42:33'),(60,89,93,91,'2026-02-06 14:48:32',1,NULL,'2026-02-06 14:48:31'),(61,82,88,84,'2026-02-06 15:10:46',1,NULL,'2026-02-06 15:10:45'),(62,87,92,89,'2026-02-06 15:12:56',1,NULL,'2026-02-06 15:12:56'),(63,85,101,93,'2026-02-06 15:40:01',1,NULL,'2026-02-06 15:40:01'),(64,79,88,83,'2026-02-06 17:42:05',1,NULL,'2026-02-06 17:42:05');
/*!40000 ALTER TABLE `heart_rate` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-09  9:35:14
